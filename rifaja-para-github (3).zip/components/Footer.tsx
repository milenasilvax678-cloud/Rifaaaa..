import Link from "next/link";
import Logo from "./Logo";
import SocialIcon, { NOME_REDE } from "./SocialIcon";
import type { Rede } from "../lib/social";

export default function Footer({ redes }: { redes: Rede[] }) {
  return (
    <footer className="mt-16 bg-[#0A1B4D] py-10 text-sm text-[#C3D1FF]">
      <div className="mx-auto grid max-w-5xl gap-6 px-4 sm:grid-cols-3">
        <div><Logo /><p className="mt-2">Sua próxima oportunidade começa aqui.</p></div>
        <div className="grid content-start gap-2"><b className="text-white">Redes oficiais</b>
          {redes.length
            ? redes.map((r) => (
              <a key={r.network} href={r.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-white">
                <span className="grid h-7 w-7 place-items-center rounded-md bg-white text-[#0A1B4D]"><SocialIcon network={r.network} size={16} /></span>{r.title || NOME_REDE[r.network]}
              </a>))
            : <span className="opacity-60">Em breve.</span>}
        </div>
        <div className="grid content-start gap-1"><b className="text-white">Institucional</b>
          <Link href="/suporte#faq">Central de ajuda</Link><Link href="/suporte">Suporte</Link><Link href="/ganhadores">Ganhadores</Link>
          <Link href="/termos">Termos de uso</Link><Link href="/privacidade">Política de privacidade</Link>
        </div>
      </div>
    </footer>
  );
}
