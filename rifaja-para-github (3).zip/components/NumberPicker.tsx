"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useFormStatus } from "react-dom";
import { AnimatePresence, motion } from "motion/react";
import { createClient } from "../lib/supabase/client";
import { iniciarPagamento } from "../app/campanhas/[slug]/actions";

type Props = { campaignId: string; slug: string; total: number; priceCents: number; limit: number | null; taken: Record<number, string>; logged: boolean; pagamentoAtivo: boolean; modo?: string; aberta: boolean; motivo: string };
const brl = (c: number) => `R$ ${(c / 100).toFixed(2).replace(".", ",")}`;
const POR_PAGINA = 100;
const MOTIVOS: Record<string, string> = {
  login_required: "Entre na sua conta para usar um cupom.", not_found: "Cupom não encontrado ou desativado.", not_started: "Este cupom ainda não começou.",
  expired: "Este cupom expirou.", min_order: "A compra não atinge o valor mínimo deste cupom.", limit_reached: "Este cupom esgotou.",
  user_limit: "Você já usou este cupom o máximo de vezes.", not_eligible: "Este cupom vale só para novos clientes ou primeira compra.",
};

function Pagar({ desativado }: { desativado: boolean }) {
  const { pending } = useFormStatus();
  return (
    <button disabled={desativado || pending} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#1E5BFF] to-[#3D72FF] p-4 text-lg font-extrabold text-white shadow-[0_8px_24px_#1E5BFF66] transition active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none">
      {pending && <span className="h-5 w-5 animate-spin rounded-full border-2 border-white border-t-transparent" aria-hidden="true" />}
      {pending ? "Verificando números e gerando o PIX…" : "Continuar para pagamento"}
    </button>
  );
}

export default function NumberPicker({ campaignId, slug, total, priceCents, limit, taken: inicial, logged, pagamentoAtivo, modo, aberta, motivo }: Props) {
  const supabase = useMemo(() => createClient(), []);
  const [taken, setTaken] = useState(inicial);
  const [sel, setSel] = useState<number[]>([]);
  const [aviso, setAviso] = useState("");
  const [aoVivo, setAoVivo] = useState(false);
  const [flash, setFlash] = useState("");
  const [pagina, setPagina] = useState(0);
  const [busca, setBusca] = useState("");
  const [cupom, setCupom] = useState("");
  const [res, setRes] = useState<{ ok: boolean; msg: string; desconto: number } | null>(null);
  const [aplicando, setAplicando] = useState(false);
  const selRef = useRef<number[]>([]);
  selRef.current = sel;

  const max = Math.min(limit ?? 100, 100);
  const paginas = Math.ceil(total / POR_PAGINA);
  const inicio = pagina * POR_PAGINA + 1;
  const fim = Math.min(total, inicio + POR_PAGINA - 1);
  const ocupados = Object.keys(taken).length;
  const vendidos = Object.values(taken).filter((s) => s === "pago").length;
  const pct = Math.round((vendidos / total) * 100);
  const subtotal = sel.length * priceCents;
  const desconto = res?.ok ? Math.min(res.desconto, subtotal) : 0;
  const totalFinal = subtotal - desconto;
  const ordenados = [...sel].sort((a, b) => a - b);

  // Ao vivo: o banco avisa cada mudança de número (Realtime). A consulta a cada 10 s é só reforço.
  useEffect(() => {
    let vivo = true;
    const aplicar = (n: number, st: string) => {
      setTaken((prev) => { const m = { ...prev }; if (st === "livre") delete m[n]; else m[n] = st; return m; });
      if (st !== "livre" && selRef.current.includes(n)) { setSel(selRef.current.filter((x) => x !== n)); setAviso(`Outra pessoa ficou com o número ${n}. Escolha outro.`); }
      else if (st === "pago") { setFlash(`O número ${n} acabou de ser comprado.`); setTimeout(() => setFlash(""), 3000); }
    };
    const canal = supabase.channel(`numeros-${campaignId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "number_status", filter: `campaign_id=eq.${campaignId}` },
        (p: { new: { number?: number; status?: string } }) => { if (vivo && p.new?.number) aplicar(Number(p.new.number), String(p.new.status)); })
      .subscribe((e: string) => setAoVivo(e === "SUBSCRIBED"));
    const atualizar = async () => {
      if (document.hidden) return;
      const { data } = await supabase.rpc("taken_numbers", { p_campaign: campaignId });
      if (!vivo || !data) return;
      const m: Record<number, string> = {};
      (data as { number: number; status: string }[]).forEach((t) => { m[t.number] = t.status; });
      setTaken(m);
      const perdidos = selRef.current.filter((n) => m[n]);
      if (perdidos.length) { setSel(selRef.current.filter((n) => !m[n])); setAviso(`Outra pessoa ficou com: ${perdidos.join(", ")}. Escolha outros números.`); }
    };
    const id = setInterval(atualizar, 10000);
    document.addEventListener("visibilitychange", atualizar);
    return () => { vivo = false; clearInterval(id); document.removeEventListener("visibilitychange", atualizar); supabase.removeChannel(canal); };
  }, [supabase, campaignId]);

  // Confere o cupom no servidor (função validate_coupon). O valor FINAL é recalculado de novo pelo servidor ao reservar.
  const conferir = async () => {
    const code = cupom.trim();
    if (!code) return setRes({ ok: false, msg: "Digite o código do cupom.", desconto: 0 });
    if (!logged) return setRes({ ok: false, msg: "Entre na sua conta para usar um cupom.", desconto: 0 });
    if (!sel.length) return setRes({ ok: false, msg: "Escolha ao menos um número antes de aplicar o cupom.", desconto: 0 });
    setAplicando(true);
    const { data, error } = await supabase.rpc("validate_coupon", { p_code: code, p_total_cents: sel.length * priceCents });
    setAplicando(false);
    if (error || !data) return setRes({ ok: false, msg: "Não foi possível conferir o cupom agora.", desconto: 0 });
    if (data.valid) setRes({ ok: true, msg: `Cupom ${code.toUpperCase()} aplicado: desconto de ${brl(data.discount_cents)}`, desconto: data.discount_cents });
    else setRes({ ok: false, msg: MOTIVOS[data.reason] ?? "Cupom inválido.", desconto: 0 });
  };
  useEffect(() => {
    if (!res?.ok) return;
    if (!sel.length) { setRes(null); return; }
    const t = setTimeout(conferir, 400);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subtotal]);

  const alternar = (n: number) => {
    if (!aberta) return;
    setAviso("");
    setSel((s) => max === 1 ? (s.includes(n) ? [] : [n]) : s.includes(n) ? s.filter((x) => x !== n) : s.length >= max ? s : [...s, n]);
  };
  const aleatorios = (q: number) => {
    if (!aberta) return;
    const d: number[] = [];
    for (let n = 1; n <= total; n++) if (!taken[n] && !sel.includes(n)) d.push(n);
    for (let i = d.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [d[i], d[j]] = [d[j], d[i]]; }
    setSel((s) => [...s, ...d.slice(0, Math.max(0, Math.min(q, max - s.length)))]);
  };
  const ir = () => { const n = Number(busca); if (Number.isInteger(n) && n >= 1 && n <= total) setPagina(Math.floor((n - 1) / POR_PAGINA)); };

  const cell = (n: number) => {
    const st = taken[n], marcado = sel.includes(n);
    const base = "h-12 rounded-xl border-2 text-sm font-extrabold transition-colors ";
    if (st === "pago") return <button key={n} type="button" disabled aria-label={`Número ${n} ocupado`} className={base + "cursor-not-allowed border-slate-200 bg-slate-200 text-slate-400 line-through"}>{n}</button>;
    if (st === "reservado" || st === "bloqueado") return <button key={n} type="button" disabled aria-label={`Número ${n} reservado`} className={base + "cursor-not-allowed border-amber-200 bg-amber-100 text-amber-700"}>{n}</button>;
    return (
      <motion.button key={n} type="button" whileTap={{ scale: 0.86 }} animate={{ scale: marcado ? 1.08 : 1 }} transition={{ type: "spring", stiffness: 500, damping: 22 }}
        onClick={() => alternar(n)} aria-pressed={marcado} aria-label={`Número ${n}, disponível`} disabled={!aberta}
        className={base + (marcado ? "border-[#1E5BFF] bg-[#1E5BFF] text-white shadow-[0_0_14px_#1E5BFF88]" : "border-slate-200 bg-white text-slate-800 hover:border-[#1E5BFF] hover:bg-[#1E5BFF]/5") + (!aberta ? " cursor-not-allowed opacity-70" : "")}>{n}</motion.button>
    );
  };
  const passo = sel.length ? 2 : 1;
  const desativado = !aberta || !sel.length || !pagamentoAtivo;

  return (
    <section className="mt-8 grid gap-5" aria-label="Escolha seus números e pague">
      {/* passos */}
      <ol className="grid grid-cols-3 gap-2 text-center text-xs font-bold sm:text-sm">
        {["Escolha os números", "Pagamento", "Confirmação"].map((t, i) => (
          <li key={t} className={`flex items-center justify-center gap-2 rounded-xl border px-2 py-2 transition-colors ${i + 1 === passo ? "border-[#1E5BFF] bg-[#1E5BFF] text-white" : i + 1 < passo ? "border-green-300 bg-green-50 text-green-800" : "bg-white text-slate-500"}`}>
            <span className={`grid h-6 w-6 place-items-center rounded-full text-xs ${i + 1 === passo ? "bg-white/25" : "bg-slate-100"}`}>{i + 1 < passo ? "✓" : i + 1}</span><span>{t}</span>
          </li>))}
      </ol>

      {/* tabela de números */}
      <div className="overflow-hidden rounded-3xl border bg-white shadow-sm">
        <div className="bg-gradient-to-r from-[#0A1B4D] to-[#13286B] p-5 text-white">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-xl font-extrabold">Tabela de números</h2>
            <span className={`rounded-full px-3 py-1 text-xs font-bold ${aoVivo ? "bg-green-400/20 text-green-300" : "bg-white/10 text-white/70"}`}>{aoVivo ? "● ao vivo" : "atualizando a cada 10 s"}</span>
          </div>
          <p className="mt-1 text-sm text-white/80">{total - ocupados} livres de {total} · {brl(priceCents)} por número · {max === 1 ? "1 número por pessoa" : `até ${max} por pedido`}</p>
          <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-white/15" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Percentual vendido">
            <motion.div className="h-full rounded-full bg-gradient-to-r from-[#6E98FF] to-[#1E5BFF]" initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 0.8 }} />
          </div>
          <p className="mt-1 text-xs text-white/70">{pct}% vendido</p>
        </div>

        <div className="p-4 sm:p-5">
          {!aberta && <p className="mb-4 rounded-xl bg-amber-100 p-3 text-sm text-amber-900">Pré-visualização: {motivo} A escolha de números abre quando a rifa for publicada.</p>}
          <div className="flex flex-wrap gap-2 text-xs font-bold" aria-label="Legenda">
            <span className="rounded-lg border-2 border-slate-200 bg-white px-2.5 py-1">Disponível</span>
            <span className="rounded-lg border-2 border-[#1E5BFF] bg-[#1E5BFF] px-2.5 py-1 text-white">Selecionado por você</span>
            <span className="rounded-lg border-2 border-amber-200 bg-amber-100 px-2.5 py-1 text-amber-700">Reservado (pagando)</span>
            <span className="rounded-lg border-2 border-slate-200 bg-slate-200 px-2.5 py-1 text-slate-500">Ocupado (pago)</span>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <input value={busca} onChange={(e) => setBusca(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), ir())} inputMode="numeric" placeholder="Ir ao número…" aria-label="Ir ao número" className="w-36 rounded-xl border-2 border-slate-200 p-2.5" />
            <button type="button" onClick={ir} className="rounded-xl border-2 px-3 py-2.5 text-sm font-bold">Ir</button>
            {aberta && max > 1 && [1, 5, 10].map((q) => <button key={q} type="button" onClick={() => aleatorios(q)} className="rounded-xl bg-[#0A1B4D] px-3 py-2.5 text-sm font-bold text-white transition hover:bg-[#1E5BFF]">+{q} aleatório{q > 1 ? "s" : ""}</button>)}
          </div>
          <AnimatePresence>{flash && <motion.p role="status" initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-3 rounded-lg bg-slate-100 p-2 text-sm">{flash}</motion.p>}</AnimatePresence>
          <motion.div key={pagina} initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4 grid grid-cols-[repeat(auto-fill,minmax(52px,1fr))] gap-2">
            {Array.from({ length: fim - inicio + 1 }, (_, i) => cell(inicio + i))}
          </motion.div>
          {paginas > 1 && (
            <div className="mt-4 flex items-center justify-between text-sm">
              <button type="button" disabled={pagina === 0} onClick={() => setPagina(pagina - 1)} className="rounded-xl border-2 px-4 py-2 font-bold disabled:opacity-40">Anterior</button>
              <span className="font-bold">{inicio}–{fim} de {total}</span>
              <button type="button" disabled={pagina >= paginas - 1} onClick={() => setPagina(pagina + 1)} className="rounded-xl border-2 px-4 py-2 font-bold disabled:opacity-40">Próxima</button>
            </div>)}
        </div>
      </div>

      {/* pagamento, logo abaixo da tabela */}
      <form id="pagamento" action={iniciarPagamento} className="scroll-mt-20 overflow-hidden rounded-3xl border bg-white shadow-sm">
        <input type="hidden" name="campaign_id" value={campaignId} />
        <input type="hidden" name="slug" value={slug} />
        <input type="hidden" name="numbers" value={JSON.stringify(sel)} />
        <input type="hidden" name="coupon" value={cupom.trim()} />
        <div className="border-b bg-slate-50 p-5"><h2 className="text-xl font-extrabold">Pagamento</h2><p className="text-sm text-slate-600">Confira sua escolha, aplique um cupom e pague com PIX.</p></div>
        <div className="grid gap-4 p-5">
          <AnimatePresence>{aviso && <motion.p role="alert" initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="rounded-xl bg-amber-100 p-3 text-sm text-amber-900">{aviso}</motion.p>}</AnimatePresence>

          <div>
            <p className="text-sm font-bold text-slate-500">Números escolhidos ({sel.length})</p>
            <div className="mt-2 flex min-h-10 flex-wrap gap-2">
              <AnimatePresence>
                {ordenados.map((n) => (
                  <motion.button key={n} type="button" layout initial={{ opacity: 0, scale: 0.6 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.6 }} onClick={() => alternar(n)}
                    className="rounded-full bg-[#1E5BFF]/10 px-3 py-1 text-sm font-extrabold text-[#1E5BFF]" aria-label={`Remover número ${n}`}>{n} ×</motion.button>))}
              </AnimatePresence>
              {!sel.length && <span className="text-sm text-slate-400">Toque nos números da tabela acima.</span>}
            </div>
          </div>

          <div>
            <label htmlFor="cupom" className="text-sm font-bold text-slate-500">Cupom de desconto</label>
            <div className="mt-1 flex gap-2">
              <input id="cupom" value={cupom} onChange={(e) => { setCupom(e.target.value.toUpperCase().replace(/\s/g, "")); setRes(null); }} placeholder="Digite o cupom" autoCapitalize="characters" className="w-full rounded-xl border-2 border-slate-200 p-3 font-bold tracking-wide" />
              <button type="button" onClick={conferir} disabled={aplicando} className="shrink-0 rounded-xl bg-[#0A1B4D] px-5 font-bold text-white disabled:opacity-60">{aplicando ? "…" : "Aplicar"}</button>
            </div>
            <AnimatePresence>{res && <motion.p role="status" initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className={`mt-2 rounded-lg p-2 text-sm font-bold ${res.ok ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>{res.msg}</motion.p>}</AnimatePresence>
          </div>

          <dl className="grid gap-2 rounded-2xl bg-slate-50 p-4 text-sm">
            <div className="flex justify-between"><dt>{sel.length} × {brl(priceCents)}</dt><dd className="font-bold">{brl(subtotal)}</dd></div>
            {desconto > 0 && <div className="flex justify-between text-green-700"><dt>Desconto do cupom</dt><dd className="font-bold">− {brl(desconto)}</dd></div>}
            <div className="flex items-end justify-between border-t pt-2"><dt className="font-bold">Total</dt>
              <dd className="text-3xl font-extrabold text-[#0A1B4D]"><motion.span key={totalFinal} initial={{ opacity: 0.4, y: 6 }} animate={{ opacity: 1, y: 0 }}>{brl(totalFinal)}</motion.span></dd></div>
          </dl>
          <p className="-mt-2 text-xs text-slate-500">O servidor confere números, cupom e valor final no momento de gerar o PIX.</p>

          {logged ? <Pagar desativado={desativado} /> : <Link href="/login" className="rounded-2xl bg-[#1E5BFF] p-4 text-center text-lg font-extrabold text-white">Entre para continuar</Link>}
          {logged && !aberta && <p className="rounded-xl bg-slate-100 p-3 text-xs text-slate-700">Pagamento indisponível: a rifa ainda não está aberta.</p>}
          {logged && aberta && !pagamentoAtivo && <p className="rounded-xl bg-slate-100 p-3 text-xs text-slate-700">Pagamento indisponível: o administrador ainda não configurou o provedor. Nenhum número é reservado até lá.</p>}
          {logged && aberta && pagamentoAtivo && <p className="text-center text-xs text-slate-500">{modo === "manual" ? "Você paga por PIX na chave do organizador. Os números ficam reservados até a equipe conferir o pagamento." : "Os números ficam reservados só enquanto você paga e só viram “pagos” quando o PIX é confirmado."}</p>}
        </div>
      </form>

      {/* barra flutuante no celular */}
      <AnimatePresence>
        {sel.length > 0 && (
          <motion.a href="#pagamento" initial={{ y: 80, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 80, opacity: 0 }}
            className="fixed inset-x-3 bottom-3 z-30 flex items-center justify-between rounded-2xl bg-[#0A1B4D] p-3 pl-4 text-white shadow-2xl sm:hidden">
            <span className="text-sm"><b>{sel.length}</b> número(s) · <b>{brl(totalFinal)}</b></span>
            <span className="rounded-xl bg-[#1E5BFF] px-4 py-2 text-sm font-extrabold">Pagar</span>
          </motion.a>)}
      </AnimatePresence>
    </section>
  );
}
