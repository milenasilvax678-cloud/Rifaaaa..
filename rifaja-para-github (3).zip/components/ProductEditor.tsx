"use client";
import { useEffect, useState } from "react";

type C = { id: string; name: string; prize: string; category: string; description: string; rules: string; organizer_info: string; starts_at: string; ends_at: string; price: string; participation_limit: string; total_numbers: string; cover_url: string | null };
const inp = "w-full rounded-xl border border-slate-300 bg-white p-3";

export default function ProductEditor({ c, action }: { c: C; action: (fd: FormData) => void | Promise<void> }) {
  const [nome, setNome] = useState(c.name);
  const [preco, setPreco] = useState(c.price);
  const [desc, setDesc] = useState(c.description);
  const [capa, setCapa] = useState<string | null>(c.cover_url);
  const [novaCapa, setNovaCapa] = useState(false);
  useEffect(() => () => { if (novaCapa && capa) URL.revokeObjectURL(capa); }, [novaCapa, capa]);
  const p = Number(String(preco).replace(",", "."));
  return (
    <div className="mt-6 grid gap-4 md:grid-cols-[1fr_260px]">
      <form action={action} className="grid gap-3 rounded-2xl border bg-white p-4 md:order-1">
        <input type="hidden" name="id" value={c.id} />
        <input name="name" required value={nome} onChange={(e) => setNome(e.target.value)} className={inp} placeholder="Nome do prêmio" />
        <label id="premio" className="grid gap-1 text-sm scroll-mt-24">Prêmio<input name="prize" defaultValue={c.prize} maxLength={160} placeholder="Prêmio (ex.: PlayStation 5 Slim 1TB)" className={inp} /></label>
        <input name="category" defaultValue={c.category} placeholder="Categoria (opcional)" className={inp} />
        <textarea name="description" value={desc} onChange={(e) => setDesc(e.target.value)} rows={3} placeholder="Descrição" className={inp} />
        <textarea name="rules" defaultValue={c.rules} rows={4} placeholder="Regulamento" className={inp} />
        <input name="organizer_info" defaultValue={c.organizer_info} placeholder="Responsável" className={inp} />
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="text-sm">Início<input type="datetime-local" name="starts_at" defaultValue={c.starts_at} className={inp} /></label>
          <label className="text-sm">Encerramento<input type="datetime-local" name="ends_at" defaultValue={c.ends_at} className={inp} /></label>
          <input name="price" inputMode="decimal" value={preco} onChange={(e) => setPreco(e.target.value)} placeholder="Valor por número em R$" className={inp} />
          <input name="participation_limit" inputMode="numeric" defaultValue={c.participation_limit} placeholder="Limite de números por pessoa" className={inp} />
          <input name="total_numbers" inputMode="numeric" defaultValue={c.total_numbers} placeholder="Quantidade de números" className={inp} />
        </div>
        <label id="foto" className="grid scroll-mt-24 gap-2 text-sm">Trocar foto do prêmio (até 5 MB)
          <input type="file" name="cover" accept="image/jpeg,image/png,image/webp" className={inp}
            onChange={(e) => { const f = e.target.files?.[0]; if (f) { setCapa(URL.createObjectURL(f)); setNovaCapa(true); } }} />
        </label>
        <button className="rounded-xl bg-[#1E5BFF] p-3 font-bold text-white">Salvar alterações</button>
        <p className="text-xs text-slate-500">Ao salvar, o site público já mostra a mudança. Não precisa mexer no código.</p>
      </form>

      <aside className="md:order-2">
        <div className="sticky top-20 overflow-hidden rounded-2xl border bg-white shadow-sm">
          <p className="bg-amber-100 px-3 py-1 text-xs font-bold text-amber-800">Prévia do cartão{novaCapa ? " · foto nova ainda não salva" : ""}</p>
          {capa /* eslint-disable-next-line @next/next/no-img-element */ ? <img src={capa} alt="Prévia da capa" className="h-36 w-full object-cover" />
            : <div className="grid h-36 place-items-center bg-[#13286B] text-4xl font-extrabold text-white">{(nome || "?").charAt(0)}</div>}
          <div className="grid gap-1 p-3">
            <h3 className="text-lg font-bold">{nome || "Nome do prêmio"}</h3>
            <p className="line-clamp-2 text-sm text-slate-600">{desc}</p>
            {!Number.isNaN(p) && preco !== "" && <p className="text-sm font-bold">R$ {p.toFixed(2).replace(".", ",")} por número</p>}
          </div>
        </div>
      </aside>
    </div>
  );
}
