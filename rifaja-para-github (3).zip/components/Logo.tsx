export default function Logo({ size = 30 }: { size?: number }) {
  return (
    <span className="inline-flex items-center gap-2 text-2xl font-extrabold text-white">
      <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
        <path d="M3 8a3 3 0 0 1 3-3h20a3 3 0 0 1 3 3v3.2a4.8 4.8 0 0 0 0 9.6V24a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3v-3.2a4.8 4.8 0 0 0 0-9.6Z" fill="#1E5BFF" />
        <path d="M13 21V11h4.2a3 3 0 0 1 0 6H13m4.2 0 2.3 4" stroke="#fff" strokeWidth="2.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <span>Rifa<span className="text-[#6E98FF]">Já</span></span>
    </span>
  );
}
