"use client";
import { useState } from "react";
export default function CopyButton({ texto }: { texto: string }) {
  const [ok, setOk] = useState(false);
  return (
    <button type="button" onClick={async () => { await navigator.clipboard.writeText(texto); setOk(true); setTimeout(() => setOk(false), 2000); }}
      className="rounded-xl bg-[#0A1B4D] px-4 py-3 font-bold text-white">{ok ? "Copiado!" : "Copiar código PIX"}</button>
  );
}
