import Link from "next/link";
import { brl } from "../lib/periodo";
type C = { slug: string; name: string; prize?: string | null; description: string | null; category: string | null; status: string; cover_url: string | null; price_cents?: number | null; total_numbers?: number | null };

export default function CampaignCard({ c, vendidos = 0, i = 0 }: { c: C; vendidos?: number; i?: number }) {
  const pct = c.total_numbers ? Math.min(100, Math.round((vendidos / c.total_numbers) * 100)) : 0;
  const rot = c.status === "agendada" ? "Em breve" : c.status === "encerrada" ? "Encerrada" : "Ativa";
  return (
    <Link href={`/campanhas/${c.slug}`} style={{ animationDelay: `${i * 0.07}s` }}
      className="rv group flex flex-col overflow-hidden rounded-3xl border bg-white shadow-sm transition duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-[#1E5BFF]/20">
      <div className="relative h-44 overflow-hidden bg-gradient-to-br from-[#13286B] to-[#1E5BFF]">
        {c.cover_url
          // eslint-disable-next-line @next/next/no-img-element
          ? <img src={c.cover_url} alt={c.name} className="h-full w-full object-cover transition duration-500 group-hover:scale-110" />
          : <div className="grid h-full place-items-center text-5xl font-extrabold text-white">{c.name.charAt(0)}</div>}
        <span className="absolute left-3 top-3 rounded-full bg-white/90 px-3 py-1 text-xs font-extrabold text-[#0A1B4D] backdrop-blur">{rot}</span>
      </div>
      <div className="grid flex-1 gap-2 p-5">
        <h3 className="text-xl font-extrabold leading-tight">{c.name}</h3>
        {c.prize && <p className="text-sm font-semibold text-[#1E5BFF]">{c.prize}</p>}
        {c.total_numbers ? (
          <>
            <div className="h-2.5 overflow-hidden rounded-full bg-slate-200" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100} aria-label="Percentual vendido">
              <div className="h-full rounded-full bg-gradient-to-r from-[#1E5BFF] to-[#7C5CFF] transition-all duration-700" style={{ width: `${pct}%` }} />
            </div>
            <p className="text-xs text-slate-500">{pct}% vendido{c.price_cents != null ? ` · ${brl(c.price_cents)} por número` : ""}</p>
          </>
        ) : c.price_cents != null && <p className="text-sm font-bold">{brl(c.price_cents)} por número</p>}
        <span className="mt-2 inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#1E5BFF] to-[#4F8BFF] px-4 py-3 text-sm font-extrabold text-white transition group-hover:brightness-110">Escolher números <span aria-hidden="true" className="transition group-hover:translate-x-1">→</span></span>
      </div>
    </Link>
  );
}
