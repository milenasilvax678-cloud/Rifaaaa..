"use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "../lib/supabase/client";

// Consulta o status REAL do pedido no banco. Quem muda o status é o webhook do provedor, nunca esta página.
export default function PaymentWatcher({ orderId, expiraEm }: { orderId: string; expiraEm: string | null }) {
  const router = useRouter();
  const supabase = useMemo(() => createClient(), []);
  const [resta, setResta] = useState<number | null>(null);
  useEffect(() => {
    const id = setInterval(async () => {
      const { data } = await supabase.from("orders").select("status").eq("id", orderId).maybeSingle();
      if (data && data.status !== "pendente") router.refresh();
    }, 4000);
    return () => clearInterval(id);
  }, [supabase, orderId, router]);
  useEffect(() => {
    if (!expiraEm) return;
    const t = () => setResta(Math.max(0, Math.floor((new Date(expiraEm).getTime() - Date.now()) / 1000)));
    t(); const id = setInterval(t, 1000);
    return () => clearInterval(id);
  }, [expiraEm]);
  return (
    <p className="flex items-center gap-2 text-sm text-slate-700" role="status">
      <span className="h-4 w-4 animate-spin rounded-full border-2 border-[#1E5BFF] border-t-transparent" aria-hidden="true" />
      Aguardando a confirmação do pagamento{resta != null ? ` · expira em ${Math.floor(resta / 60)}:${String(resta % 60).padStart(2, "0")}` : ""}
    </p>
  );
}
