export type Ganhador = { id: string; winner_name: string; winning_number: number | null; announcement: string | null; proof_url: string | null; drawn_at: string | null; campaigns: { name: string; prize?: string | null; cover_url?: string | null } | null };

export default function WinnerCard({ g, i = 0, total }: { g: Ganhador; i?: number; total?: number }) {
  const c = g.campaigns;
  const num = g.winning_number != null ? String(g.winning_number).padStart(String(total ?? 0).length, "0") : null;
  return (
    <article style={{ animationDelay: `${i * 0.08}s` }} className="rv overflow-hidden rounded-3xl border bg-white shadow-sm transition duration-300 hover:-translate-y-1.5 hover:shadow-2xl hover:shadow-purple-500/20">
      <div className="flex items-center justify-between bg-gradient-to-r from-[#F59E0B] via-[#F97316] to-[#EF4444] px-5 py-3 text-white">
        <span className="text-3xl" aria-hidden="true">🏆</span>
        {num && <span className="rounded-full bg-black/25 px-4 py-1 text-lg font-extrabold">Nº {num}</span>}
      </div>
      {c?.cover_url /* eslint-disable-next-line @next/next/no-img-element */ && <img src={c.cover_url} alt={c.name} className="h-36 w-full object-cover" />}
      <div className="grid gap-2 p-5">
        {g.drawn_at && <small className="font-bold text-slate-500">{new Date(g.drawn_at + "T12:00").toLocaleDateString("pt-BR")}</small>}
        <h3 className="text-xl font-extrabold leading-tight">{c?.name}</h3>
        {c?.prize && <p className="text-sm text-slate-600">{c.prize}</p>}
        <p className="rounded-2xl bg-slate-100 px-4 py-3"><small className="block text-slate-500">Ganhador(a)</small><b className="text-xl">{g.winner_name}</b></p>
        {g.announcement && <p className="text-sm text-slate-600">{g.announcement}</p>}
        {g.proof_url && <a href={g.proof_url} target="_blank" rel="noopener noreferrer" className="text-sm font-extrabold text-[#1E5BFF] underline">Ver comprovante</a>}
      </div>
    </article>
  );
}
