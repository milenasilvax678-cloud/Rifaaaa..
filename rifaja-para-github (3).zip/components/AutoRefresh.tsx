"use client";
import { useEffect, useMemo } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "../lib/supabase/client";

// Atualiza a página do painel sozinha: na hora quando um número muda (se houver campaignId) e, como reforço, a cada alguns segundos.
export default function AutoRefresh({ campaignId, intervalMs = 10000 }: { campaignId?: string; intervalMs?: number }) {
  const router = useRouter();
  const supabase = useMemo(() => createClient(), []);
  useEffect(() => {
    let t: ReturnType<typeof setTimeout>;
    const agora = () => { clearTimeout(t); t = setTimeout(() => router.refresh(), 400); };
    const id = setInterval(() => { if (!document.hidden) router.refresh(); }, intervalMs);
    const canal = campaignId
      ? supabase.channel(`painel-numeros-${campaignId}`).on("postgres_changes", { event: "*", schema: "public", table: "number_status", filter: `campaign_id=eq.${campaignId}` }, agora).subscribe()
      : null;
    return () => { clearInterval(id); clearTimeout(t); if (canal) supabase.removeChannel(canal); };
  }, [supabase, router, campaignId, intervalMs]);
  return null;
}
