"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const ITENS: [string, string, string][] = [
  ["Visão geral", "/admin", "M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"],
  ["Produtos e prêmios", "/admin/produtos", "M20 12v9H4v-9M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z"],
  ["Rifas e campanhas", "/admin/campanhas", "M3 8a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-4z"],
  ["Cupons promocionais", "/admin/cupons", "M20 12l-8 8-9-9V3h8zM7.5 7.5h.01"],
  ["Compras e compradores", "/admin/compras", "M6 7h12l1 13H5zM9 7a3 3 0 0 1 6 0"],
  ["Compradores", "/admin/compradores", "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"],
  ["Pagamentos", "/admin/pagamentos", "M3 6h18v12H3zM3 10h18"],
  ["Financeiro", "/admin/financeiro", "M12 2v20M17 6H9.5a3 3 0 0 0 0 6h5a3 3 0 0 1 0 6H6"],
  ["Sorteios e ganhadores", "/admin/resultados", "M12 15a6 6 0 1 0 0-12 6 6 0 0 0 0 12zM8.5 14L7 22l5-3 5 3-1.5-8"],
  ["Suporte", "/admin/suporte", "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM9.1 9a3 3 0 0 1 5.8 1c0 2-3 2.5-3 4M12 17.5h.01"],
  ["Cargos e acessos", "/admin/cargos", "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"],
  ["Auditoria", "/admin/auditoria", "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"],
  ["Configurações", "/admin/configuracoes", "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"],
];
const Ic = ({ d }: { d: string }) => <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={d} /></svg>;

export default function AdminSidebar() {
  const path = usePathname();
  const ativo = (h: string) => (h === "/admin" ? path === "/admin" : path.startsWith(h));
  return (
    <>
      <nav aria-label="Menu do painel" className="sticky top-16 hidden h-[calc(100vh-5rem)] w-64 shrink-0 overflow-y-auto rounded-3xl border border-[#7F8FFF33] bg-[#0B1440]/80 p-3 backdrop-blur lg:block">
        {ITENS.map(([t, h, d]) => (
          <Link key={h} href={h} aria-current={ativo(h) ? "page" : undefined}
            className={`mb-1 flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition-colors ${ativo(h) ? "bg-gradient-to-r from-[#4F46E5] to-[#2D6BFF] text-white shadow-[0_0_18px_#4F46E577]" : "text-[#C3D1FF] hover:bg-white/10"}`}>
            <Ic d={d} />{t}
          </Link>))}
      </nav>
      <nav aria-label="Menu do painel" className="-mx-3 mb-3 flex gap-2 overflow-x-auto px-3 pb-1 lg:hidden">
        {ITENS.map(([t, h]) => (
          <Link key={h} href={h} className={`shrink-0 rounded-full border px-4 py-2 text-sm font-semibold ${ativo(h) ? "border-transparent bg-gradient-to-r from-[#4F46E5] to-[#2D6BFF] text-white" : "border-[#7F8FFF44] text-[#C3D1FF]"}`}>{t}</Link>))}
      </nav>
    </>
  );
}
