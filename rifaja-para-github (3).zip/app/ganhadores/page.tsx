import { createClient } from "../../lib/supabase/server";
import WinnerCard, { type Ganhador } from "../../components/WinnerCard";
export const dynamic = "force-dynamic";

export default async function Ganhadores() {
  const supabase = await createClient();
  const { data } = await supabase.from("campaign_results").select("id,winner_name,winning_number,announcement,proof_url,drawn_at,campaigns(name,prize,cover_url)").eq("published", true).order("created_at", { ascending: false });
  return (
    <main>
      <section className="bg-[radial-gradient(60%_90%_at_80%_0,#F59E0B44,transparent),radial-gradient(50%_70%_at_0_100%,#7C5CFF44,transparent),#0A1B4D] px-4 py-14 text-white">
        <div className="mx-auto max-w-5xl">
          <h1 className="rv text-4xl font-extrabold md:text-6xl">Ganhadores</h1>
          <p className="rv mt-3 max-w-xl text-lg text-[#C3D1FF]" style={{ animationDelay: ".1s" }}>Resultados oficiais, com o número sorteado, a data e o comprovante.</p>
        </div>
      </section>
      <div className="mx-auto max-w-5xl px-4 py-10">
        {data?.length
          ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{(data as unknown as Ganhador[]).map((g, i) => <WinnerCard key={g.id} g={g} i={i} />)}</div>
          : <p className="rounded-3xl border-2 border-dashed border-slate-300 p-8 text-center text-slate-600">Ainda não há resultados publicados. Não exibimos ganhadores de exemplo.</p>}
      </div>
    </main>
  );
}
