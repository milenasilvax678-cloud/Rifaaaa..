export default function Pagina() {
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">Termos de uso</h1>
      <p className="mt-4 rounded-xl bg-amber-100 p-4 text-amber-900">
        Texto provisório. Antes de publicar o site, substitua por versão revisada por advogado, com razão social, CNPJ e
        contato do responsável preenchidos pela empresa. Nenhum dado empresarial foi inventado aqui.
      </p>
      <p className="mt-4 text-slate-700">Conteúdo a ser fornecido pelo responsável jurídico da RifaJá.</p>
    </main>
  );
}
