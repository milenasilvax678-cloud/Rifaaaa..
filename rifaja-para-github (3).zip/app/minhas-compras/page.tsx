import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "../../lib/supabase/server";
import { brl } from "../../lib/periodo";
import PaymentWatcher from "../../components/PaymentWatcher";
export const dynamic = "force-dynamic";
export const metadata = { title: "Minhas compras · RifaJá" };

const ST: Record<string, [string, string]> = { confirmado: ["Pago", "bg-green-100 text-green-800"], pendente: ["Aguardando pagamento", "bg-amber-100 text-amber-800"], cancelado: ["Cancelado", "bg-slate-200 text-slate-700"], reembolsado: ["Reembolsado", "bg-red-100 text-red-800"] };

export default async function MinhasCompras() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  // A regra do banco só devolve as compras e os números DESTA conta.
  const [{ data: pedidos }, { data: nums }] = await Promise.all([
    supabase.from("orders").select("id,status,total_cents,quantity,created_at,campaigns(name,prize,cover_url,slug)").eq("user_id", user.id).order("created_at", { ascending: false }),
    supabase.from("campaign_numbers").select("order_id,number,status").eq("user_id", user.id).order("number"),
  ]);
  const por = (id: string) => (nums ?? []).filter((n: any) => n.order_id === id).map((n: any) => n.number as number);
  const pagos = (pedidos ?? []).filter((p: any) => p.status === "confirmado");
  const totalNums = pagos.reduce((a: number, p: any) => a + por(p.id).length, 0);
  const pendentes = (pedidos ?? []).filter((p: any) => p.status === "pendente");
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      {pendentes.length > 0 && <PaymentWatcher orderId={pendentes[0].id} expiraEm={null} />}
      <h1 className="text-3xl font-extrabold md:text-4xl">Minhas compras</h1>
      <p className="mt-1 text-slate-600">Só você vê esta página. Aqui ficam seus pedidos e os seus números.</p>
      <div className="mt-5 grid grid-cols-3 gap-3 text-center">
        {[[pagos.length, "compras pagas"], [totalNums, "números seus"], [pendentes.length, "aguardando"]].map(([v, t]) => (
          <div key={String(t)} className="rv rounded-2xl border bg-white p-3 shadow-sm"><div className="text-2xl font-extrabold">{v}</div><div className="text-xs text-slate-500">{t}</div></div>))}
      </div>

      <div className="mt-6 grid gap-4">
        {pedidos?.map((p: any, i: number) => {
          const c = p.campaigns, ns = por(p.id), st = ST[p.status] ?? [p.status, "bg-slate-200"];
          return (
            <article key={p.id} style={{ animationDelay: `${i * 0.06}s` }} className="rv overflow-hidden rounded-3xl border bg-white shadow-sm transition hover:shadow-lg">
              <div className="flex gap-4 p-4">
                {c?.cover_url /* eslint-disable-next-line @next/next/no-img-element */ ? <img src={c.cover_url} alt="" className="h-20 w-20 shrink-0 rounded-2xl object-cover" />
                  : <div className="grid h-20 w-20 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-[#13286B] to-[#1E5BFF] text-2xl font-extrabold text-white">{(c?.name ?? "?").charAt(0)}</div>}
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center justify-between gap-2"><h2 className="truncate text-lg font-extrabold">{c?.name}</h2><span className={`rounded-full px-3 py-1 text-xs font-extrabold ${st[1]}`}>{st[0]}</span></div>
                  {c?.prize && <p className="text-sm text-slate-600">{c.prize}</p>}
                  <p className="mt-1 text-xs text-slate-500">{new Date(p.created_at).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo", dateStyle: "short", timeStyle: "short" })} · {brl(p.total_cents)}</p>
                </div>
              </div>
              <div className="border-t bg-slate-50 px-4 py-3">
                {ns.length ? (
                  <div className="flex flex-wrap gap-2" aria-label="Números">
                    {ns.map((n) => <span key={n} className={`rounded-full px-3 py-1 text-sm font-extrabold ${p.status === "confirmado" ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800"}`}>{n}</span>)}
                  </div>
                ) : <p className="text-sm text-slate-500">{p.status === "cancelado" || p.status === "reembolsado" ? "Números liberados." : "Sem números neste pedido."}</p>}
                {p.status === "pendente" && <Link href={`/conta/pedido/${p.id}`} className="mt-3 inline-block rounded-xl bg-[#1E5BFF] px-4 py-2 text-sm font-extrabold text-white">Pagar agora</Link>}
              </div>
            </article>);
        })}
        {!pedidos?.length && (
          <div className="rounded-3xl border-2 border-dashed p-8 text-center text-slate-600">
            <p>Você ainda não comprou nenhum número.</p>
            <Link href="/campanhas" className="mt-3 inline-block rounded-xl bg-[#1E5BFF] px-5 py-3 font-extrabold text-white">Ver rifas</Link>
          </div>)}
      </div>
    </main>
  );
}
