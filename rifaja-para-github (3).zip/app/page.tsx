import Link from "next/link";
import { createClient } from "../lib/supabase/server";
import Reveal from "../components/Reveal";
import CampaignCard from "../components/CampaignCard";
import WinnerCard, { type Ganhador } from "../components/WinnerCard";
import SocialCards from "../components/SocialCards";
import { redesPublicas } from "../lib/social";
export const dynamic = "force-dynamic";

const cols = "id,slug,name,prize,description,category,status,cover_url,price_cents,total_numbers";
const PASSOS = [
  ["Crie sua conta", "Entre com Google ou e-mail em segundos."],
  ["Escolha os números", "A tabela mostra o que está livre, reservado ou pago."],
  ["Pague com PIX", "O número é seu quando o pagamento é confirmado."],
  ["Acompanhe", "Veja suas compras e os resultados oficiais no site."],
];
export default async function Home() {
  const supabase = await createClient();
  const redesHome = (await redesPublicas(supabase)).filter((r) => r.show_home);
  const [{ data: ativas }, { data: futuras }, { data: resultados }, { data: cont }] = await Promise.all([
    supabase.from("campaigns").select(cols).eq("status", "ativa").order("created_at", { ascending: false }),
    supabase.from("campaigns").select(cols).eq("status", "agendada").order("starts_at"),
    supabase.from("campaign_results").select("id,winner_name,winning_number,announcement,proof_url,drawn_at,campaigns(name,prize,cover_url)").eq("published", true).order("created_at", { ascending: false }).limit(3),
    supabase.rpc("campaign_counts"),
  ]);
  const vend = (id: string) => (cont ?? []).find((x: any) => x.campaign_id === id)?.sold ?? 0;
  const totalVendidos = (cont ?? []).reduce((a: number, c: any) => a + c.sold, 0);
  const vazio = (t: string) => <p className="rounded-3xl border-2 border-dashed border-slate-300 p-8 text-center text-slate-600">{t}</p>;
  const grade = (l: any[]) => <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{l.map((c, i) => <CampaignCard key={c.slug} c={c} i={i} vendidos={vend(c.id ?? "")} />)}</div>;
  const stats: [string | number, string][] = [[ativas?.length ?? 0, "rifas ativas"], [totalVendidos, "números vendidos"], [resultados?.length ?? 0, "resultados publicados"]];
  return (
    <main>
      <section className="relative overflow-hidden bg-[radial-gradient(60%_90%_at_85%_0,#2D6BFF77,transparent),radial-gradient(50%_70%_at_0_100%,#7C5CFF66,transparent),#0A1B4D] px-4 pb-24 pt-16 text-white">
        <svg className="flutua pointer-events-none absolute -right-8 top-10 w-64 opacity-15 sm:w-80" viewBox="0 0 32 32" aria-hidden="true"><path d="M3 8a3 3 0 0 1 3-3h20a3 3 0 0 1 3 3v3.2a4.8 4.8 0 0 0 0 9.6V24a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3v-3.2a4.8 4.8 0 0 0 0-9.6Z" fill="#fff" /></svg>
        <div className="relative mx-auto max-w-5xl">
          <span className="rv inline-block rounded-full border border-white/25 bg-white/10 px-4 py-1 text-sm font-bold backdrop-blur">RifaJá · rifas online com PIX</span>
          <h1 className="rv mt-4 max-w-3xl text-5xl font-extrabold leading-[1.02] tracking-tight md:text-7xl" style={{ animationDelay: ".08s" }}>Sua próxima oportunidade começa aqui.</h1>
          <p className="rv mt-5 max-w-xl text-lg text-[#C3D1FF] md:text-xl" style={{ animationDelay: ".16s" }}>Escolha seus números, pague com PIX e acompanhe tudo na sua conta. Regras claras e resultados oficiais.</p>
          <div className="rv mt-8 flex flex-wrap gap-3" style={{ animationDelay: ".24s" }}>
            <Link href="/campanhas" className="brilho rounded-2xl bg-gradient-to-r from-[#1E5BFF] to-[#4F8BFF] px-7 py-4 text-lg font-extrabold">Ver rifas</Link>
            <Link href="/#como" className="rounded-2xl border border-white/40 px-7 py-4 text-lg font-extrabold transition hover:bg-white/10">Como funciona</Link>
          </div>
          {stats.some(([v]) => Number(v) > 0) && (
            <dl className="rv mt-10 flex flex-wrap gap-3" style={{ animationDelay: ".32s" }}>
              {stats.map(([v, t]) => <div key={t} className="rounded-2xl border border-white/15 bg-white/10 px-5 py-3 backdrop-blur"><dd className="text-2xl font-extrabold">{v}</dd><dt className="text-xs text-[#C3D1FF]">{t}</dt></div>)}
            </dl>)}
        </div>
      </section>

      <div className="mx-auto grid max-w-5xl gap-16 px-4 py-14">
        <Reveal><div id="rifas" className="scroll-mt-24" />
          <h2 className="text-3xl font-extrabold md:text-4xl">Rifas disponíveis</h2>
          <p className="mb-6 mt-1 text-slate-600">Cada rifa tem tabela de números própria, valor por número e regulamento.</p>
          {ativas?.length ? grade(ativas) : vazio("Nenhuma rifa ativa no momento. As rifas publicadas pelo administrador aparecem aqui automaticamente.")}</Reveal>
        {!!futuras?.length && <Reveal><h2 className="mb-6 text-3xl font-extrabold md:text-4xl">Em breve</h2>{grade(futuras)}</Reveal>}

        <Reveal>
          <div id="promocoes" className="scroll-mt-24 flex flex-wrap items-center justify-between gap-4 rounded-3xl bg-gradient-to-r from-[#4F46E5] to-[#2D6BFF] p-7 text-white shadow-xl">
            <div><h2 className="text-2xl font-extrabold">Tem um cupom de desconto?</h2><p className="mt-1 text-white/85">Digite na hora de pagar. O sistema confere validade e limites.</p></div>
            <Link href="/campanhas" className="rounded-xl bg-white px-6 py-3 font-extrabold text-[#0A1B4D]">Escolher números</Link>
          </div>
        </Reveal>

        <Reveal>
          <div className="mb-6 flex flex-wrap items-end justify-between gap-3"><h2 className="text-3xl font-extrabold md:text-4xl">Ganhadores</h2><Link href="/ganhadores" className="rounded-xl border px-5 py-2 font-bold hover:bg-white">Ver todos</Link></div>
          {resultados?.length ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{(resultados as unknown as Ganhador[]).map((g, i) => <WinnerCard key={g.id} g={g} i={i} />)}</div>
            : vazio("Ainda não há resultados publicados. Não exibimos ganhadores de exemplo.")}
        </Reveal>

        <Reveal><div id="como" className="scroll-mt-24" /><h2 className="text-3xl font-extrabold md:text-4xl">Como funciona</h2>
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {PASSOS.map(([t, d], i) => (
              <div key={t} className="rounded-3xl border bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:shadow-lg">
                <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-[#1E5BFF] to-[#7C5CFF] text-lg font-extrabold text-white">{i + 1}</span>
                <h3 className="mt-3 text-lg font-extrabold">{t}</h3><p className="mt-1 text-sm text-slate-600">{d}</p>
              </div>))}
          </div></Reveal>

        {redesHome.length > 0 && <Reveal><h2 className="mb-6 text-3xl font-extrabold md:text-4xl">Siga o RifaJá</h2><SocialCards redes={redesHome} /></Reveal>}

        <Reveal><div id="ajuda" className="scroll-mt-24" /><h2 className="mb-6 text-3xl font-extrabold md:text-4xl">Perguntas frequentes</h2>
          {[["Preciso de conta para participar?", "Sim. A conta guarda suas compras e os seus números."],
            ["Quando meu número fica como pago?", "Quando o pagamento é confirmado. Voltar ao site não confirma nada."],
            ["Posso ver o que já comprei?", "Sim, em Minhas compras, no menu, depois de entrar na sua conta."],
            ["Toda rifa aceita participação paga?", "Não. Cada rifa só fica ativa depois da validação jurídica feita pelo responsável."]].map(([q, a]) => (
            <details key={q} className="mb-3 rounded-2xl border bg-white p-4 transition open:shadow-md"><summary className="cursor-pointer font-extrabold">{q}</summary><p className="mt-2 text-slate-600">{a}</p></details>
          ))}</Reveal>
      </div>
    </main>
  );
}
