"use server";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { createHash, timingSafeEqual } from "crypto";
import { createClient } from "../../lib/supabase/server";
import { COOKIE_NAME, criarCookie } from "../../lib/admin-gate";

export async function entrar(fd: FormData) {
  const volta = (m: string): never => redirect(`/acesso-restrito?erro=${encodeURIComponent(m)}`);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("is_admin")).data) redirect("/"); // quem não é administrador nem vê que esta página existe
  const segredo = process.env.ADMIN_ACCESS_KEY;
  if (!segredo || segredo.length < 12) volta("A chave de acesso ainda não foi configurada no servidor (variável ADMIN_ACCESS_KEY, mínimo de 12 caracteres).");
  const { data: st } = await supabase.rpc("admin_gate_status");
  if (st?.locked) volta(`Muitas tentativas erradas. Tente de novo em ${st.minutes} min.`);
  const a = createHash("sha256").update(String(fd.get("chave") ?? "")).digest();
  const b = createHash("sha256").update(segredo).digest();
  if (!timingSafeEqual(a, b)) { await supabase.rpc("admin_gate_fail"); volta("Chave incorreta."); }
  await supabase.rpc("admin_gate_ok");
  (await cookies()).set(COOKIE_NAME, await criarCookie(user.id, segredo), {
    httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "strict", path: "/", maxAge: 8 * 3600,
  });
  redirect("/admin");
}

export async function bloquear() {
  (await cookies()).delete(COOKIE_NAME);
  redirect("/");
}
