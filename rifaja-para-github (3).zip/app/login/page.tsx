"use client";
import { useState } from "react";
import { createClient } from "../../lib/supabase/client";

export default function Login() {
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [msg, setMsg] = useState("");
  const redirectTo = () => `${location.origin}/auth/callback`;

  async function google() {
    await supabase.auth.signInWithOAuth({ provider: "google", options: { redirectTo: redirectTo() } });
  }
  async function entrar() {
    const { error } = await supabase.auth.signInWithPassword({ email, password: senha });
    if (error) setMsg("E-mail ou senha incorretos."); else location.href = "/conta";
  }
  async function cadastrar() {
    const { error } = await supabase.auth.signUp({ email, password: senha, options: { emailRedirectTo: redirectTo() } });
    setMsg(error ? error.message : "Enviamos um e-mail para confirmar sua conta.");
  }
  async function recuperar() {
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: redirectTo() });
    setMsg(error ? error.message : "Se o e-mail existir, enviaremos o link de recuperação.");
  }
  const input = "w-full rounded-xl border border-slate-300 bg-white p-3";
  return (
    <main className="mx-auto max-w-sm px-4 py-10">
      <h1 className="mb-4 text-3xl font-extrabold">Entrar na RifaJá</h1>
      <button onClick={google} className="mb-4 w-full rounded-xl border border-slate-300 bg-white p-3 font-bold">Continuar com Google</button>
      <div className="grid gap-3">
        <input className={input} type="email" placeholder="E-mail" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input className={input} type="password" placeholder="Senha" value={senha} onChange={(e) => setSenha(e.target.value)} />
        <button onClick={entrar} className="rounded-xl bg-[#1E5BFF] p-3 font-bold text-white">Entrar</button>
        <button onClick={cadastrar} className="rounded-xl border border-[#1E5BFF] p-3 font-bold text-[#1E5BFF]">Criar conta</button>
        <button onClick={recuperar} className="text-sm text-slate-500 underline">Esqueci minha senha</button>
        {msg && <p role="status" className="text-sm">{msg}</p>}
      </div>
    </main>
  );
}
