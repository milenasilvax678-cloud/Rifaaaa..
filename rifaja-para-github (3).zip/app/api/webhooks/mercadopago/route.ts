import { NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "crypto";
import { adminClient } from "../../../../lib/supabase/admin";
import { buscarPagamento } from "../../../../lib/payments/mercadopago";
export const dynamic = "force-dynamic";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function assinaturaValida(req: Request, dataId: string, secret: string) {
  const partes: Record<string, string> = {};
  (req.headers.get("x-signature") ?? "").split(",").forEach((p) => { const [k, v] = p.split("="); if (k && v) partes[k.trim()] = v.trim(); });
  if (!partes.ts || !partes.v1) return false;
  const manifesto = `id:${dataId.toLowerCase()};request-id:${req.headers.get("x-request-id") ?? ""};ts:${partes.ts};`;
  const esperado = Buffer.from(createHmac("sha256", secret).update(manifesto).digest("hex"));
  const recebido = Buffer.from(partes.v1);
  return esperado.length === recebido.length && timingSafeEqual(esperado, recebido);
}

export async function POST(req: Request) {
  const secret = process.env.MERCADOPAGO_WEBHOOK_SECRET;
  if (!secret || !process.env.MERCADOPAGO_ACCESS_TOKEN) return NextResponse.json({ error: "Pagamento não configurado" }, { status: 503 });
  const url = new URL(req.url);
  const corpo = await req.json().catch(() => ({}));
  const dataId = String(url.searchParams.get("data.id") ?? corpo?.data?.id ?? "");
  const tipo = url.searchParams.get("type") ?? corpo?.type;

  // 1) notificação falsa: assinatura inválida é recusada
  if (!/^\d+$/.test(dataId) || !assinaturaValida(req, dataId, secret)) return NextResponse.json({ error: "assinatura inválida" }, { status: 401 });
  if (tipo !== "payment") return NextResponse.json({ ok: true, ignorado: true });

  try {
    // 2) o status vem do provedor, não da notificação
    const pg = await buscarPagamento(dataId);
    const orderId = pg.external_reference ?? "";
    if (!UUID.test(orderId)) return NextResponse.json({ ok: true, ignorado: true });
    const centavos = Math.round(Number(pg.transaction_amount) * 100);
    const evento = `${pg.id}:${pg.status}`;
    const db = adminClient();

    // 3) o banco garante: evento repetido, valor correto, números ainda reservados, sem confirmação dupla
    if (pg.status === "approved") {
      const { data, error } = await db.rpc("confirm_payment", { p_order: orderId, p_provider: "mercadopago", p_payment_id: String(pg.id), p_amount_cents: centavos, p_event_id: evento });
      if (error) throw error;
      return NextResponse.json({ ok: true, resultado: data });
    }
    if (pg.status === "rejected" || pg.status === "cancelled") {
      const novo = (pg.status_detail ?? "").includes("expired") ? "expirado" : "recusado";
      const { data, error } = await db.rpc("fail_payment", { p_order: orderId, p_provider: "mercadopago", p_payment_id: String(pg.id), p_new_status: novo, p_event_id: evento });
      if (error) throw error;
      return NextResponse.json({ ok: true, resultado: data });
    }
    return NextResponse.json({ ok: true, ignorado: true });
  } catch {
    return NextResponse.json({ error: "falha ao processar" }, { status: 500 }); // o provedor tenta de novo
  }
}
