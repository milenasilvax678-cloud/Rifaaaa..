import { createClient } from "../../lib/supabase/server";
import CampaignCard from "../../components/CampaignCard";
export const dynamic = "force-dynamic";
export default async function Campanhas() {
  const supabase = await createClient();
  const { data: cont } = await supabase.rpc("campaign_counts");
  const { data } = await supabase.from("campaigns").select("id,slug,name,prize,description,category,status,cover_url,price_cents,total_numbers").order("created_at", { ascending: false });
  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">Rifas</h1>
      {data?.length
        ? <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{data.map((c, i) => <CampaignCard key={c.slug} c={c} i={i} vendidos={(cont ?? []).find((x: any) => x.campaign_id === c.id)?.sold ?? 0} />)}</div>
        : <p className="mt-6 rounded-2xl border-2 border-dashed p-5 text-slate-600">Nenhuma campanha publicada ainda.</p>}
    </main>
  );
}
