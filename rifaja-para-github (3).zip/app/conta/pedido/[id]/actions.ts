"use server";
import { redirect } from "next/navigation";
import { createClient } from "../../../../lib/supabase/server";
export async function cancelarPedido(fd: FormData) {
  const id = String(fd.get("id"));
  const supabase = await createClient();
  const { error } = await supabase.rpc("cancel_order", { p_order: id });
  redirect(error ? `/conta/pedido/${id}?erro=${encodeURIComponent(error.message)}` : "/conta?ok=Pedido cancelado.");
}
