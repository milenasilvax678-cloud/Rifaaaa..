import Link from "next/link";
import { createClient } from "../../lib/supabase/server";
import { brl } from "../../lib/periodo";
import { salvarPerfil, usarCodigo } from "./actions";
export const dynamic = "force-dynamic";
const inp = "w-full rounded-xl border border-slate-300 bg-white p-3";

export default async function Conta({ searchParams }: { searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const [perfil, pedidos, cupons, notifs, indicados] = await Promise.all([
    supabase.from("profiles").select("full_name,phone,referral_code,referred_by").eq("id", user!.id).maybeSingle(),
    supabase.from("orders").select("id,total_cents,status,quantity,created_at").eq("user_id", user!.id).order("created_at", { ascending: false }),
    supabase.from("coupon_redemptions").select("id,discount_cents,created_at").eq("user_id", user!.id).order("created_at", { ascending: false }),
    supabase.from("notifications").select("id,title,body").eq("user_id", user!.id).order("created_at", { ascending: false }).limit(20),
    supabase.rpc("referral_count"),
  ]);
  const p = perfil.data;
  const Vazio = ({ t }: { t: string }) => <p className="mt-3 rounded-xl border-2 border-dashed p-4 text-slate-600">{t}</p>;
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-extrabold">Minha conta</h1>
      <p className="mt-2 text-slate-600">{user?.email}</p>
      <Link href="/minhas-compras" className="mt-3 inline-block rounded-xl bg-[#1E5BFF] px-5 py-3 font-bold text-white">Minhas compras e números</Link>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}

      <form action={salvarPerfil} className="mt-6 grid gap-3 rounded-2xl border bg-white p-4">
        <h2 className="text-xl font-bold">Seus dados</h2>
        <p className="text-sm text-slate-600">Nome e telefone são necessários para reservar números e para identificar sua participação.</p>
        <input name="full_name" defaultValue={p?.full_name ?? ""} placeholder="Nome completo" className={inp} />
        <input name="phone" defaultValue={p?.phone ?? ""} placeholder="Telefone com DDD" inputMode="tel" className={inp} />
        <button className="rounded-xl bg-[#1E5BFF] p-3 font-bold text-white">Salvar</button>
      </form>

      <h2 className="mt-8 text-xl font-bold">Minhas participações</h2>
      {pedidos.data?.length ? <ul className="mt-3 grid gap-2">{pedidos.data.map((o: any) => (
        <li key={o.id}><Link href={`/conta/pedido/${o.id}`} className="block rounded-xl border bg-white p-3 hover:border-[#1E5BFF]">
          {o.quantity} número(s) · {brl(o.total_cents)} · <b>{o.status}</b> · {new Date(o.created_at).toLocaleDateString("pt-BR")}</Link></li>))}</ul>
        : <Vazio t="Você ainda não tem participações." />}

      <div id="indicacao" />
      <h2 className="mt-8 text-xl font-bold">Indique amigos</h2>
      <div className="mt-3 rounded-2xl border bg-white p-4">
        <p>Seu código: <b className="text-[#1E5BFF]">{p?.referral_code}</b></p>
        <p className="text-sm text-slate-600">Amigos indicados: {indicados.data ?? 0}. Compartilhe o código; a recompensa será definida pela RifaJá.</p>
        {!p?.referred_by && (
          <form action={usarCodigo} className="mt-3 flex gap-2">
            <input name="code" placeholder="Foi indicado por alguém? Digite o código" className={inp} />
            <button className="rounded-xl border px-4 font-bold">Enviar</button>
          </form>)}
      </div>

      <h2 className="mt-8 text-xl font-bold">Cupons usados</h2>
      {cupons.data?.length ? <ul className="mt-3 grid gap-2">{cupons.data.map((c: any) => (
        <li key={c.id} className="rounded-xl border bg-white p-3">Desconto de {brl(c.discount_cents)} · {new Date(c.created_at).toLocaleDateString("pt-BR")}</li>))}</ul> : <Vazio t="Nenhum cupom usado." />}
      <h2 className="mt-8 text-xl font-bold">Notificações</h2>
      {notifs.data?.length ? <ul className="mt-3 grid gap-2">{notifs.data.map((n: any) => (
        <li key={n.id} className="rounded-xl border bg-white p-3"><b>{n.title}</b><br />{n.body}</li>))}</ul> : <Vazio t="Sem notificações." />}
      <form action="/auth/signout" method="post" className="mt-8"><button className="rounded-xl border px-4 py-2 font-bold">Sair</button></form>
    </main>
  );
}
