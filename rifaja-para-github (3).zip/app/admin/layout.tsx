import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { COOKIE_NAME, cookieValido } from "../../lib/admin-gate";
import { bloquear } from "../acesso-restrito/actions";
import { createClient } from "../../lib/supabase/server";
import AdminSidebar from "../../components/AdminSidebar";
export const metadata = { robots: { index: false, follow: false } };

// Segunda barreira: só quem está na tabela de administradores (e não revogado) entra em /admin.
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("is_admin")).data) redirect("/");
  if (!(await cookieValido((await cookies()).get(COOKIE_NAME)?.value, user.id, process.env.ADMIN_ACCESS_KEY))) redirect("/acesso-restrito");
  return (
    <div className="admin-dark min-h-screen bg-[#050B24] bg-[radial-gradient(ellipse_at_top_left,#2433b855,transparent_55%),radial-gradient(ellipse_at_bottom_right,#6d28d933,transparent_50%)]">
      <div className="mx-auto flex max-w-[1500px] gap-5 px-3 py-5 lg:px-5">
        <AdminSidebar />
        <div className="min-w-0 flex-1">
          <header className="mb-5 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl font-extrabold text-white sm:text-3xl">Painel Administrativo <span className="text-[#8FB0FF]">· RifaJá</span></h1>
              <p className="text-sm text-[#9FB0E8]">Gerencie tudo de forma simples e segura.</p>
            </div>
            <form action={bloquear}><button className="rounded-full border border-[#7F8FFF44] px-4 py-2 text-sm font-bold text-[#C3D1FF] hover:bg-white/10">🔒 Bloquear painel</button></form>
            <div className="flex items-center gap-2 rounded-full border border-[#7F8FFF44] bg-[#0B1440]/80 py-1.5 pl-2 pr-4 text-sm">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-gradient-to-br from-[#4F46E5] to-[#2D6BFF] font-bold text-white">{(user.email ?? "A").charAt(0).toUpperCase()}</span>
              <span className="leading-tight"><b className="block max-w-[180px] truncate">{user.email}</b><span className="text-xs text-green-400">● Online</span></span>
            </div>
          </header>
          {children}
        </div>
      </div>
    </div>
  );
}
