"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../lib/supabase/server";

const slugify = (t: string) =>
  t.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") +
  "-" + Math.random().toString(36).slice(2, 6);
const txt = (fd: FormData, k: string) => (String(fd.get(k) ?? "").trim() || null);
const num = (fd: FormData, k: string) => { const v = txt(fd, k); return v ? Number(v.replace(",", ".")) : null; };
const date = (fd: FormData, k: string) => { const v = txt(fd, k); return v ? new Date(`${v}:00-03:00`).toISOString() : null; };
const done = (ok: boolean, msg: string): never => redirect(`/admin/campanhas?${ok ? "ok" : "erro"}=${encodeURIComponent(msg)}`);

export async function criarCampanha(fd: FormData) {
  const supabase = await createClient();
  const nome = txt(fd, "name");
  if (!nome) done(false, "Informe o nome da campanha.");
  const legal = fd.get("legal") === "on";
  const publicar = legal && fd.get("publicar") === "on";
  const preco = num(fd, "price");
  const { data: nova, error } = await supabase.from("campaigns").insert({
    name: nome, slug: slugify(nome!), prize: txt(fd, "prize"), description: txt(fd, "description"), category: txt(fd, "category"),
    rules: txt(fd, "rules"), organizer_info: txt(fd, "organizer_info"),
    price_cents: preco == null ? null : Math.round(preco * 100),
    participation_limit: num(fd, "participation_limit"), total_numbers: num(fd, "total_numbers"),
    starts_at: date(fd, "starts_at"), ends_at: date(fd, "ends_at"), legal_validated: legal, status: publicar ? "ativa" : "rascunho",
  }).select("id").single();
  let aviso = "";
  const arq = fd.get("cover") as File | null;
  if (!error && nova && arq && arq.size > 0) {
    const path = `${nova.id}/cover-${Date.now()}-${arq.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    const up = await supabase.storage.from("campaign-images").upload(path, arq);
    if (up.error) aviso = " Mas a imagem não subiu: " + up.error.message;
    else await supabase.from("campaigns").update({ cover_url: supabase.storage.from("campaign-images").getPublicUrl(path).data.publicUrl }).eq("id", nova.id);
  }
  revalidatePath("/admin/campanhas"); revalidatePath("/", "layout");
  done(!error, error ? error.message : (publicar ? "Rifa publicada: já aparece no site, com a tabela de números e o pagamento." : "Rifa criada como RASCUNHO: ela ainda não aparece no site. Em Produtos, use Publicar (e marque a validação jurídica) para ela entrar no ar.") + aviso);
}

export async function mudarStatus(fd: FormData) {
  const supabase = await createClient();
  const { error } = await supabase.from("campaigns").update({ status: txt(fd, "status") }).eq("id", txt(fd, "id"));
  revalidatePath("/admin/campanhas"); revalidatePath("/", "layout");
  done(!error, error ? error.message : "Status atualizado.");
}

export async function validarJuridico(fd: FormData) {
  const supabase = await createClient();
  const { error } = await supabase.from("campaigns").update({ legal_validated: fd.get("valor") === "1" }).eq("id", txt(fd, "id"));
  revalidatePath("/admin/campanhas"); revalidatePath("/", "layout");
  done(!error, error ? error.message : "Validação jurídica atualizada.");
}
