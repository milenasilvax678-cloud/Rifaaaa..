"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../../lib/supabase/server";

const txt = (fd: FormData, k: string) => (String(fd.get(k) ?? "").trim() || null);
const num = (fd: FormData, k: string) => { const v = txt(fd, k); return v ? Number(v.replace(",", ".")) : null; };
const date = (fd: FormData, k: string) => { const v = txt(fd, k); return v ? new Date(`${v}:00-03:00`).toISOString() : null; };
const nomeSeguro = (n: string) => n.replace(/[^a-zA-Z0-9._-]/g, "_");
const done = (id: string, ok: boolean, msg: string): never => redirect(`/admin/campanhas/${id}?${ok ? "ok" : "erro"}=${encodeURIComponent(msg)}`);

export async function editarCampanha(fd: FormData) {
  const supabase = await createClient();
  const id = txt(fd, "id")!;
  const preco = num(fd, "price");
  const dados: Record<string, unknown> = {
    name: txt(fd, "name"), prize: txt(fd, "prize"), description: txt(fd, "description"), category: txt(fd, "category"),
    rules: txt(fd, "rules"), organizer_info: txt(fd, "organizer_info"),
    price_cents: preco == null ? null : Math.round(preco * 100), participation_limit: num(fd, "participation_limit"), total_numbers: num(fd, "total_numbers"),
    starts_at: date(fd, "starts_at"), ends_at: date(fd, "ends_at"),
  };
  const capa = fd.get("cover") as File | null;
  if (capa && capa.size > 0) {
    const path = `${id}/cover-${Date.now()}-${nomeSeguro(capa.name)}`;
    const up = await supabase.storage.from("campaign-images").upload(path, capa);
    if (up.error) done(id, false, "Falha no upload da capa: " + up.error.message);
    dados.cover_url = supabase.storage.from("campaign-images").getPublicUrl(path).data.publicUrl;
  }
  const { error } = await supabase.from("campaigns").update(dados).eq("id", id);
  revalidatePath(`/admin/campanhas/${id}`); revalidatePath("/", "layout");
  done(id, !error, error ? error.message : "Campanha atualizada.");
}

export async function enviarFotos(fd: FormData) {
  const supabase = await createClient();
  const id = txt(fd, "id")!;
  const arquivos = (fd.getAll("fotos") as File[]).filter((f) => f.size > 0);
  if (!arquivos.length) done(id, false, "Escolha pelo menos uma foto.");
  const { count } = await supabase.from("campaign_images").select("*", { count: "exact", head: true }).eq("campaign_id", id);
  let pos = count ?? 0;
  for (const f of arquivos) {
    const path = `${id}/gal-${Date.now()}-${nomeSeguro(f.name)}`;
    const up = await supabase.storage.from("campaign-images").upload(path, f);
    if (up.error) done(id, false, "Falha no upload: " + up.error.message);
    const url = supabase.storage.from("campaign-images").getPublicUrl(path).data.publicUrl;
    const { error } = await supabase.from("campaign_images").insert({ campaign_id: id, url, position: pos++ });
    if (error) done(id, false, error.message);
  }
  revalidatePath(`/admin/campanhas/${id}`); revalidatePath("/", "layout");
  done(id, true, "Fotos adicionadas.");
}

export async function removerFoto(fd: FormData) {
  const supabase = await createClient();
  const id = txt(fd, "id")!;
  const { error } = await supabase.from("campaign_images").delete().eq("id", txt(fd, "foto_id"));
  revalidatePath(`/admin/campanhas/${id}`); revalidatePath("/", "layout");
  done(id, !error, error ? error.message : "Foto removida.");
}

export async function excluirCampanha(fd: FormData) {
  const supabase = await createClient();
  const id = txt(fd, "id")!;
  const { error, count } = await supabase.from("campaigns").delete({ count: "exact" }).eq("id", id);
  if (error) done(id, false, error.code === "23503" ? "Há pedidos ligados a esta rifa. Mude o status para cancelada em vez de excluir." : error.message);
  if (!count) done(id, false, "Só o dono pode excluir rifas.");
  redirect("/admin/campanhas?ok=" + encodeURIComponent("Rifa excluída."));
}
