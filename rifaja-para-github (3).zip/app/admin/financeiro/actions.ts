"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../lib/supabase/server";

const txt = (fd: FormData, k: string) => (String(fd.get(k) ?? "").trim() || null);
const reais = (fd: FormData, k: string) => { const v = txt(fd, k); return v ? Math.round(Number(v.replace(",", ".")) * 100) : NaN; };
const done = (ok: boolean, msg: string): never => redirect(`/admin/financeiro?${ok ? "ok" : "erro"}=${encodeURIComponent(msg)}`);

export async function criarDespesa(fd: FormData) {
  const supabase = await createClient();
  const valor = reais(fd, "amount");
  if (!txt(fd, "description") || !(valor > 0)) done(false, "Informe a descrição e um valor maior que zero.");
  let comprovante = txt(fd, "receipt_url");
  const arq = fd.get("receipt_file") as File | null;
  if (arq && arq.size > 0) {
    const { data: { user } } = await supabase.auth.getUser();
    const path = `${user!.id}/${Date.now()}-${arq.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    const up = await supabase.storage.from("receipts").upload(path, arq);
    if (up.error) done(false, "Falha no upload do comprovante: " + up.error.message);
    comprovante = path;
  }
  const { error } = await supabase.from("expenses").insert({
    description: txt(fd, "description"), amount_cents: valor, category: txt(fd, "category"),
    receipt_url: comprovante, incurred_on: txt(fd, "incurred_on") ?? undefined,
  });
  revalidatePath("/admin/financeiro");
  done(!error, error ? error.message : "Despesa registrada.");
}

export async function criarAjuste(fd: FormData) {
  const supabase = await createClient();
  const valor = reais(fd, "amount");
  if (!txt(fd, "description") || Number.isNaN(valor) || valor === 0) done(false, "Informe a descrição e um valor diferente de zero.");
  const j = txt(fd, "justification") ?? "";
  if (j.length < 10) done(false, "A justificativa precisa ter pelo menos 10 caracteres.");
  const sinal = fd.get("sinal") === "menos" ? -1 : 1;
  const { error } = await supabase.from("financial_adjustments").insert({
    description: txt(fd, "description"), amount_cents: Math.abs(valor) * sinal, justification: j,
  });
  revalidatePath("/admin/financeiro");
  done(!error, error ? error.message : "Ajuste registrado e auditado.");
}
