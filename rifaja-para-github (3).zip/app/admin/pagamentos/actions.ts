"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../lib/supabase/server";
export async function confirmarManual(fd: FormData) {
  const supabase = await createClient();
  const { error } = await supabase.rpc("manual_confirm_order", { p_order: String(fd.get("order_id")), p_reason: String(fd.get("reason") ?? "") });
  revalidatePath("/admin/pagamentos");
  redirect(`/admin/pagamentos?${error ? "erro" : "ok"}=${encodeURIComponent(error ? error.message : "Confirmação manual registrada e auditada.")}`);
}
