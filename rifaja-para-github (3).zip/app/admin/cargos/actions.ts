"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../lib/supabase/server";

const txt = (fd: FormData, k: string) => (String(fd.get(k) ?? "").trim() || null);
const done = (ok: boolean, msg: string): never => redirect(`/admin/cargos?${ok ? "ok" : "erro"}=${encodeURIComponent(msg)}`);
// Todas as regras valem também no banco (RLS e triggers): só o dono altera cargos e acessos.

export async function criarCargo(fd: FormData) {
  const supabase = await createClient();
  const nome = txt(fd, "name");
  if (!nome) done(false, "Informe o nome do cargo.");
  const { error } = await supabase.from("roles").insert({ name: nome!.toLowerCase().replace(/\s+/g, "_"), description: txt(fd, "description") });
  revalidatePath("/admin/cargos");
  done(!error, error ? (error.code === "23505" ? "Já existe um cargo com esse nome." : error.message) : "Cargo criado. Agora marque as permissões.");
}

export async function excluirCargo(fd: FormData) {
  const supabase = await createClient();
  const { error } = await supabase.from("roles").delete().eq("id", txt(fd, "role_id")).eq("is_system", false);
  revalidatePath("/admin/cargos");
  done(!error, error ? (error.code === "23503" ? "Há administradores usando esse cargo. Troque o cargo deles antes." : error.message) : "Cargo removido.");
}

export async function salvarPermissoes(fd: FormData) {
  const supabase = await createClient();
  const roleId = txt(fd, "role_id")!;
  const novas = new Set(fd.getAll("perm").map(String));
  const { data: atuais } = await supabase.from("role_permissions").select("permission_key").eq("role_id", roleId);
  const antigas = new Set((atuais ?? []).map((x) => x.permission_key));
  const remover = [...antigas].filter((k) => !novas.has(k));
  const incluir = [...novas].filter((k) => !antigas.has(k));
  if (remover.length) {
    const { error } = await supabase.from("role_permissions").delete().eq("role_id", roleId).in("permission_key", remover);
    if (error) done(false, error.message);
  }
  if (incluir.length) {
    const { error } = await supabase.from("role_permissions").insert(incluir.map((k) => ({ role_id: roleId, permission_key: k })));
    if (error) done(false, error.message);
  }
  revalidatePath("/admin/cargos");
  done(true, "Permissões salvas.");
}

export async function adicionarAdmin(fd: FormData) {
  const supabase = await createClient();
  const email = txt(fd, "email");
  if (!email) done(false, "Informe o e-mail.");
  const { data: perfil } = await supabase.from("profiles").select("id").ilike("email", email!).maybeSingle();
  if (!perfil) done(false, "Essa pessoa ainda não criou conta no RifaJá.");
  const { data: { user } } = await supabase.auth.getUser();
  const { error } = await supabase.from("admin_members").insert({ user_id: perfil!.id, role_id: txt(fd, "role_id"), granted_by: user?.id });
  revalidatePath("/admin/cargos");
  done(!error, error ? (error.code === "23505" ? "Essa pessoa já é administradora." : error.message) : "Administrador adicionado.");
}

export async function alterarCargoAdmin(fd: FormData) {
  const supabase = await createClient();
  const { error } = await supabase.from("admin_members").update({ role_id: txt(fd, "role_id") }).eq("user_id", txt(fd, "user_id"));
  revalidatePath("/admin/cargos");
  done(!error, error ? error.message : "Cargo alterado.");
}

export async function revogarAcesso(fd: FormData) {
  const supabase = await createClient();
  const revogar = fd.get("revogar") === "1";
  const { error } = await supabase.from("admin_members").update({ revoked_at: revogar ? new Date().toISOString() : null }).eq("user_id", txt(fd, "user_id"));
  revalidatePath("/admin/cargos");
  done(!error, error ? error.message : revogar ? "Acesso revogado." : "Acesso restaurado.");
}
