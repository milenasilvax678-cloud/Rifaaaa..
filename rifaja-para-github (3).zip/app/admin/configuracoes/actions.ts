"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../lib/supabase/server";

const REDES = ["instagram", "tiktok", "whatsapp", "youtube", "facebook", "telegram", "discord"];
const NOMES: Record<string, string> = { instagram: "Instagram", tiktok: "TikTok", whatsapp: "WhatsApp", youtube: "YouTube", facebook: "Facebook", telegram: "Telegram", discord: "Discord" };
const volta = (ok: boolean, m: string): never => redirect(`/admin/configuracoes?${ok ? "ok" : "erro"}=${encodeURIComponent(m)}`);

export async function salvarPix(fd: FormData) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const chave = String(fd.get("pix_key") ?? "").trim(), nome = String(fd.get("pix_name") ?? "").trim().slice(0, 25), cidade = String(fd.get("pix_city") ?? "").trim().slice(0, 15);
  if (!chave || chave.length < 5 || chave.length > 80) volta(false, "Informe a chave PIX (CPF, e-mail, telefone com +55 ou chave aleatória).");
  const { error } = await supabase.from("payment_settings").upsert({ id: 1, pix_key: chave, pix_name: nome || null, pix_city: cidade || null, updated_by: user?.id, updated_at: new Date().toISOString() });
  revalidatePath("/", "layout");
  volta(!error, error ? error.message : "Chave PIX salva. Os pedidos novos já usam essa chave.");
}

export async function salvarRedes(fd: FormData) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const linhas = [];
  for (const n of REDES) {
    const g = (k: string) => String(fd.get(`${n}__${k}`) ?? "").trim();
    const ativa = fd.get(`${n}__enabled`) === "on", url = g("url");
    if (url && !/^https:\/\/[^\s]+$/i.test(url)) volta(false, `O link do ${NOMES[n]} precisa começar com https://`);
    if (ativa && !url) volta(false, `Informe o link do ${NOMES[n]} para ativá-lo. Rede sem link não é exibida.`);
    linhas.push({
      network: n, enabled: ativa, url: url || null,
      title: g("title").slice(0, 60) || null, description: g("description").slice(0, 160) || null,
      position: Number.parseInt(g("position")) || 0,
      show_footer: fd.get(`${n}__footer`) === "on", show_home: fd.get(`${n}__home`) === "on", show_contact: fd.get(`${n}__contact`) === "on",
      updated_by: user?.id,
    });
  }
  const { error } = await supabase.from("social_links").upsert(linhas, { onConflict: "network" });
  revalidatePath("/", "layout"); // o site inteiro passa a mostrar as mudanças
  volta(!error, error ? error.message : "Redes sociais salvas. O site já foi atualizado.");
}
