import { redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "../../../lib/supabase/server";
import { CATEGORIAS, STATUS, quando } from "../../../lib/suporte";
import AdminNav from "../nav";
import StatusBadge from "../../../components/StatusBadge";
import AutoRefresh from "../../../components/AutoRefresh";
export const dynamic = "force-dynamic";

export default async function CentralSuporte({ searchParams }: { searchParams: Promise<{ q?: string; status?: string; categoria?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("has_permission", { perm: "support.read" })).data) redirect("/admin");
  const q = (sp.q ?? "").trim();
  let consulta = supabase.from("support_tickets").select("id,ticket_number,subject,category,status,name,email,created_at,updated_at").order("updated_at", { ascending: false }).limit(100);
  if (sp.status && STATUS[sp.status]) consulta = consulta.eq("status", sp.status);
  if (sp.categoria && CATEGORIAS[sp.categoria]) consulta = consulta.eq("category", sp.categoria);
  if (/^#?\d+$/.test(q)) consulta = consulta.eq("ticket_number", Number(q.replace("#", "")));
  else if (q) consulta = consulta.ilike("subject", `%${q.replace(/[%_]/g, "")}%`);
  const [{ data: lista }, { count: pendentes }] = await Promise.all([
    consulta,
    supabase.from("support_tickets").select("*", { count: "exact", head: true }).in("status", ["aberto", "em_atendimento"]),
  ]);
  const sel = "rounded-xl border border-slate-300 bg-white p-3";
  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <AdminNav />
      <AutoRefresh intervalMs={10000} />
      <h1 className="text-3xl font-extrabold">Central de Suporte</h1>
      <p className="mt-1"><span className={`rounded-full px-3 py-1 text-sm font-bold ${pendentes ? "bg-red-100 text-red-800" : "bg-green-100 text-green-800"}`}>{pendentes ?? 0} aguardando a equipe</span></p>
      <form className="mt-5 grid gap-2 sm:grid-cols-[1fr_auto_auto_auto]">
        <input name="q" defaultValue={q} placeholder="Buscar por assunto ou número (#123)" className={sel} />
        <select name="status" defaultValue={sp.status ?? ""} className={sel}><option value="">Todos os status</option>{Object.entries(STATUS).map(([v, s]) => <option key={v} value={v}>{s.rot}</option>)}</select>
        <select name="categoria" defaultValue={sp.categoria ?? ""} className={sel}><option value="">Todas as categorias</option>{Object.entries(CATEGORIAS).map(([v, t]) => <option key={v} value={v}>{t}</option>)}</select>
        <button className="rounded-xl bg-[#1E5BFF] px-5 py-3 font-bold text-white">Filtrar</button>
      </form>
      <ul className="mt-5 grid gap-3">
        {lista?.map((c: any) => {
          const precisa = c.status === "aberto" || c.status === "em_atendimento";
          return (
            <li key={c.id}>
              <Link href={`/admin/suporte/${c.id}`} className={`block rounded-2xl border bg-white p-4 transition hover:border-[#1E5BFF] ${precisa ? "border-l-4 border-l-red-500" : ""}`}>
                <div className="flex flex-wrap items-center justify-between gap-2"><b>#{c.ticket_number} · {c.subject}</b><StatusBadge status={c.status} /></div>
                <p className="mt-1 text-xs text-slate-500">{c.name} · {c.email} · {CATEGORIAS[c.category]} · aberto {quando(c.created_at)} · atualizado {quando(c.updated_at)}</p>
              </Link>
            </li>);
        })}
        {!lista?.length && <li className="rounded-xl border-2 border-dashed p-5 text-slate-600">Nenhum chamado encontrado.</li>}
      </ul>
    </main>
  );
}
