import { notFound, redirect } from "next/navigation";
import Link from "next/link";
import { createClient } from "../../../../lib/supabase/server";
import { CATEGORIAS, STATUS, quando } from "../../../../lib/suporte";
import AdminNav from "../../nav";
import StatusBadge from "../../../../components/StatusBadge";
import SubmitButton from "../../../../components/SubmitButton";
import AutoRefresh from "../../../../components/AutoRefresh";
import { responderStaff, alterarStatusChamado } from "../actions";
export const dynamic = "force-dynamic";

export default async function ChamadoStaff({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ ok?: string; erro?: string }> }) {
  const { id } = await params;
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("has_permission", { perm: "support.read" })).data) redirect("/admin");
  const pode = !!(await supabase.rpc("has_permission", { perm: "support.write" })).data;
  const { data: t } = await supabase.from("support_tickets").select("*").eq("id", id).maybeSingle();
  if (!t) notFound();
  const { data: msgs } = await supabase.from("ticket_messages").select("id,is_staff,is_internal,body,created_at").eq("ticket_id", id).order("created_at");
  return (
    <main className="mx-auto max-w-3xl px-4 py-10">
      <AdminNav />
      <AutoRefresh intervalMs={8000} />
      <Link href="/admin/suporte" className="text-sm font-bold text-[#1E5BFF]">← Central de Suporte</Link>
      <h1 className="mt-2 text-2xl font-extrabold">#{t.ticket_number} · {t.subject}</h1>
      <p className="mt-1 text-sm text-slate-600">{t.name} · {t.email}</p>
      <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-slate-500"><StatusBadge status={t.status} /><span>{CATEGORIAS[t.category]}</span><span>aberto {quando(t.created_at)}</span><span>atualizado {quando(t.updated_at)}</span></div>
      {sp.ok && <p role="status" className="mt-3 rounded-xl bg-green-100 p-3 text-green-900">{sp.ok}</p>}
      {sp.erro && <p role="alert" className="mt-3 rounded-xl bg-red-100 p-3 text-red-900">{sp.erro}</p>}

      <ul className="mt-6 grid gap-3" aria-label="Histórico da conversa">
        {msgs?.map((m: any) => (
          <li key={m.id} className={`max-w-[90%] rounded-2xl p-3 ${m.is_internal ? "mx-auto border border-amber-300 bg-amber-50" : m.is_staff ? "ml-auto bg-[#0A1B4D] text-white" : "mr-auto border bg-white"}`}>
            <p className={`text-xs font-bold ${m.is_staff && !m.is_internal ? "text-white/70" : "text-slate-500"}`}>{m.is_internal ? "Nota interna (usuário não vê)" : m.is_staff ? "Equipe" : t.name} · {quando(m.created_at)}</p>
            <p className="mt-1 whitespace-pre-line">{m.body}</p>
          </li>))}
      </ul>

      {pode ? (
        <div className="mt-6 grid gap-4">
          <form action={responderStaff} className="grid gap-2 rounded-2xl border bg-white p-4">
            <input type="hidden" name="id" value={t.id} />
            <textarea name="body" required maxLength={4000} rows={4} placeholder="Resposta ao usuário…" className="w-full rounded-xl border border-slate-300 p-3" />
            <label className="flex gap-2 text-sm"><input type="checkbox" name="internal" /> Nota interna (só a equipe vê, o usuário não é avisado)</label>
            <SubmitButton carregando="Enviando…">Enviar</SubmitButton>
          </form>
          <form action={alterarStatusChamado} className="flex flex-wrap items-center gap-2 rounded-2xl border bg-white p-4">
            <input type="hidden" name="id" value={t.id} />
            <label className="text-sm font-bold">Status do atendimento</label>
            <select name="status" defaultValue={t.status} className="rounded-xl border border-slate-300 p-3">{Object.entries(STATUS).map(([v, s]) => <option key={v} value={v}>{s.rot}</option>)}</select>
            <button className="rounded-xl bg-[#0A1B4D] px-4 py-3 font-bold text-white">Salvar status</button>
          </form>
        </div>
      ) : <p className="mt-6 rounded-xl bg-slate-100 p-4 text-sm">Seu cargo só consulta chamados. Para responder é preciso a permissão <b>support.write</b>.</p>}
    </main>
  );
}
