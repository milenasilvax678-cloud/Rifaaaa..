import { redirect } from "next/navigation";
import { createClient } from "../../../lib/supabase/server";
import { brl } from "../../../lib/periodo";
import AutoRefresh from "../../../components/AutoRefresh";
export const dynamic = "force-dynamic";

type Linha = { order_status: string; total_cents: number; campaign_name: string | null; buyer_name: string | null; buyer_email: string | null; buyer_phone: string | null; picked: number[] };

export default async function Compradores({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const sp = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  if (!(await supabase.rpc("has_permission", { perm: "buyers.read" })).data) redirect("/admin");
  const { data } = await supabase.rpc("admin_orders");
  const pessoas = new Map<string, { nome: string; email: string; tel: string; pago: number; rifas: Map<string, { pagos: number[]; pend: number[] }> }>();
  ((data ?? []) as Linha[]).forEach((o) => {
    if (o.order_status === "cancelado" || o.order_status === "reembolsado") return;
    const k = o.buyer_email ?? o.buyer_name ?? "?";
    const p = pessoas.get(k) ?? { nome: o.buyer_name ?? "Sem nome", email: o.buyer_email ?? "", tel: o.buyer_phone ?? "", pago: 0, rifas: new Map() };
    const r = p.rifas.get(o.campaign_name ?? "Rifa") ?? { pagos: [], pend: [] };
    if (o.order_status === "confirmado") { r.pagos.push(...(o.picked ?? [])); p.pago += o.total_cents; } else r.pend.push(...(o.picked ?? []));
    p.rifas.set(o.campaign_name ?? "Rifa", r); pessoas.set(k, p);
  });
  const q = (sp.q ?? "").trim().toLowerCase();
  const lista = [...pessoas.values()].filter((p) => !q || [p.nome, p.email, p.tel].some((x) => x.toLowerCase().includes(q)) || [...p.rifas.values()].some((r) => [...r.pagos, ...r.pend].includes(Number(q))))
    .sort((a, b) => b.pago - a.pago);
  const sel = "rounded-xl border border-slate-300 bg-white p-3";
  return (
    <main>
      <AutoRefresh intervalMs={10000} />
      <h2 className="text-2xl font-extrabold text-white">Compradores</h2>
      <p className="text-sm text-[#9FB0E8]">Cada pessoa e os números que comprou. Dados pessoais protegidos: só quem tem a permissão <b>buyers.read</b> vê esta página.</p>
      <form className="mt-4 flex gap-2"><input name="q" defaultValue={sp.q ?? ""} placeholder="Buscar por nome, e-mail, telefone ou número" className={sel + " flex-1"} /><button className="rounded-xl bg-gradient-to-r from-[#7C5CFF] to-[#4F46E5] px-5 font-bold text-white">Buscar</button></form>
      <div className="mt-5 grid gap-4 lg:grid-cols-2">
        {lista.map((p) => (
          <section key={p.email + p.nome} className="rounded-3xl border border-[#7F8FFF33] bg-[#0F1A55]/60 p-5">
            <div className="flex items-start justify-between gap-2"><div><h3 className="text-lg font-extrabold text-white">{p.nome}</h3><p className="text-sm text-[#9FB0E8]">{p.email} · {p.tel || "sem telefone"}</p></div><b className="text-green-300">{brl(p.pago)}</b></div>
            {[...p.rifas.entries()].map(([nome, r]) => (
              <div key={nome} className="mt-3 border-t border-[#7F8FFF22] pt-3 text-sm">
                <b className="text-white">{nome}</b>
                <div className="mt-1 flex flex-wrap gap-1.5">
                  {[...new Set(r.pagos)].sort((a, b) => a - b).map((n) => <span key={"p" + n} className="rounded-full bg-green-400/20 px-2.5 py-0.5 font-bold text-green-300">{n}</span>)}
                  {[...new Set(r.pend)].sort((a, b) => a - b).map((n) => <span key={"a" + n} className="rounded-full bg-amber-400/20 px-2.5 py-0.5 font-bold text-amber-300" title="Aguardando pagamento">{n}</span>)}
                </div>
              </div>))}
          </section>))}
        {!lista.length && <p className="rounded-3xl border-2 border-dashed border-[#7F8FFF55] p-8 text-center text-[#9FB0E8] lg:col-span-2">Nenhum comprador {q ? "neste filtro" : "ainda"}.</p>}
      </div>
      <p className="mt-3 text-xs text-[#9FB0E8]">Verde: pago. Amarelo: aguardando pagamento.</p>
    </main>
  );
}
