"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "../../../lib/supabase/server";

const PERMITIDOS = ["ativa", "pausada", "pendente_revisao"];
export async function mudarStatusProduto(fd: FormData) {
  const supabase = await createClient();
  const status = String(fd.get("status"));
  if (!PERMITIDOS.includes(status)) redirect("/admin/produtos?erro=Status+inv%C3%A1lido");
  // As regras de quem pode publicar/pausar e a exigência de validação jurídica são aplicadas no banco.
  const { error } = await supabase.from("campaigns").update({ status }).eq("id", String(fd.get("id")));
  revalidatePath("/", "layout");
  const msg = error ? error.message : status === "ativa" ? "Rifa publicada." : status === "pausada" ? "Rifa pausada." : "Enviada para revisão.";
  redirect(`/admin/produtos?${error ? "erro" : "ok"}=${encodeURIComponent(msg)}`);
}
