// PIX copia e cola (BR Code estático) com valor. Pagamento direto para a chave do dono: a confirmação é manual, auditada.
const tlv = (id: string, v: string) => id + String(v.length).padStart(2, "0") + v;
function crc16(s: string) {
  let c = 0xffff;
  for (let i = 0; i < s.length; i++) { c ^= s.charCodeAt(i) << 8; for (let j = 0; j < 8; j++) c = c & 0x8000 ? ((c << 1) ^ 0x1021) & 0xffff : (c << 1) & 0xffff; }
  return c.toString(16).toUpperCase().padStart(4, "0");
}
const limpa = (s: string, n: number) => s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^A-Za-z0-9 ]/g, "").toUpperCase().trim().slice(0, n);

export function normalizaChave(k: string) {
  const t = k.trim();
  if (/^\d{3}\.?\d{3}\.?\d{3}-?\d{2}$/.test(t) || /^\d{2}\.?\d{3}\.?\d{3}\/?\d{4}-?\d{2}$/.test(t)) return t.replace(/\D/g, ""); // CPF/CNPJ
  if (/^\+/.test(t)) return t.replace(/[\s()-]/g, ""); // telefone
  return t; // e-mail ou chave aleatória
}
export function formataChave(k: string) {
  return /^\d{11}$/.test(k) ? k.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4") : k;
}
export function brCode(p: { chave: string; nome?: string | null; cidade?: string | null; valorCentavos: number; txid: string }) {
  const conta = tlv("00", "br.gov.bcb.pix") + tlv("01", normalizaChave(p.chave));
  const body =
    tlv("00", "01") + tlv("01", "11") + tlv("26", conta) + tlv("52", "0000") + tlv("53", "986") +
    tlv("54", (p.valorCentavos / 100).toFixed(2)) + tlv("58", "BR") +
    tlv("59", limpa(p.nome || "", 25) || "RIFAJA") + tlv("60", limpa(p.cidade || "", 15) || "BRASIL") +
    tlv("62", tlv("05", p.txid.replace(/[^A-Za-z0-9]/g, "").slice(0, 25) || "***")) + "6304";
  return body + crc16(body);
}
