export const CATEGORIAS: Record<string, string> = { conta: "Conta", pagamento: "Pagamento", participacao: "Participação", campanha: "Campanha", outro: "Outro" };
export const STATUS: Record<string, { rot: string; cls: string }> = {
  aberto: { rot: "Aberto", cls: "bg-blue-100 text-blue-800" },
  em_atendimento: { rot: "Em atendimento", cls: "bg-indigo-100 text-indigo-800" },
  aguardando_resposta: { rot: "Aguardando resposta", cls: "bg-amber-100 text-amber-800" },
  resolvido: { rot: "Resolvido", cls: "bg-green-100 text-green-800" },
};
export const quando = (v: string) => new Date(v).toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo", dateStyle: "short", timeStyle: "short" });
