// O botão de pagamento só funciona quando TUDO abaixo estiver configurado no servidor.
export const pagamentoConfigurado = () =>
  !!process.env.MERCADOPAGO_ACCESS_TOKEN && !!process.env.MERCADOPAGO_WEBHOOK_SECRET &&
  !!process.env.SUPABASE_SERVICE_ROLE_KEY && !!process.env.NEXT_PUBLIC_SITE_URL;
