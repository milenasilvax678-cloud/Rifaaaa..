import "server-only";
// Adaptador do Mercado Pago (PIX). NÃO foi testado contra a conta real: valide no ambiente de testes antes de publicar.
const API = "https://api.mercadopago.com";
const token = () => process.env.MERCADOPAGO_ACCESS_TOKEN!;

export async function criarPix(p: { orderId: string; valorCentavos: number; descricao: string; email: string; expiraEm: Date }) {
  const res = await fetch(`${API}/v1/payments`, {
    method: "POST", cache: "no-store",
    headers: { Authorization: `Bearer ${token()}`, "Content-Type": "application/json", "X-Idempotency-Key": p.orderId },
    body: JSON.stringify({
      transaction_amount: p.valorCentavos / 100,
      description: p.descricao,
      payment_method_id: "pix",
      payer: { email: p.email },
      external_reference: p.orderId,
      notification_url: `${process.env.NEXT_PUBLIC_SITE_URL}/api/webhooks/mercadopago`,
      date_of_expiration: p.expiraEm.toISOString().replace("Z", "+00:00"),
    }),
  });
  if (!res.ok) throw new Error(`Mercado Pago respondeu ${res.status}`);
  const j = await res.json();
  const t = j.point_of_interaction?.transaction_data;
  if (!j.id || !t?.qr_code) throw new Error("Resposta sem QR Code");
  return { id: String(j.id), qr: String(t.qr_code), qr64: (t.qr_code_base64 as string) ?? null, ticket: (t.ticket_url as string) ?? null };
}

// Fonte da verdade: consulta o pagamento direto no provedor (não confia no corpo da notificação).
export async function buscarPagamento(id: string) {
  const res = await fetch(`${API}/v1/payments/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${token()}` }, cache: "no-store" });
  if (!res.ok) throw new Error(`Consulta falhou: ${res.status}`);
  return (await res.json()) as { id: number; status: string; status_detail?: string; transaction_amount: number; external_reference?: string };
}
